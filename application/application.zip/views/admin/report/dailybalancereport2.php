<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper">
    <section class="content-header">
        <?php echo $pagetitle; ?>
        <?php echo $breadcrumb; ?>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-default">
                    <div class="box-body">
                        <div class="row">
                            <form id="filterform">
                                <div class="col-md-4">
                                    <div class="input-daterange input-group" id="datepicker">
                                        <input type="hidden" class="form-control" name="startdate" value="<?php echo date("Y-m-d") ?>"/>
                                        <!-- <span class="input-group-addon">to</span> -->
                                        <input type="text" class="form-control" name="enddate"  id="enddate" value="<?php echo date("Y-m-d") ?>"/>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-control" name="route" id="route" multiple="multiple">
                                        <option value="">--select location--</option>
                                        <?php foreach ($locations AS $loc) { ?>
                                            <option value="<?php echo $loc->location_id ?>"><?php echo $loc->location ?></option>
                                        <?php } ?>
                                    </select>
                                    <input type="hidden" name="route_ar" id="route_ar">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-flat btn-success">Show</button>
                                </div>
                            </form>
                            <div class="col-md-2">
                                <button onclick="printdiv()" class="btn btn-flat btn-default">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" id="printReport">
            <div class="col-md-12">
                <div class="box box-default">
                    <div class="box-body table-responsive">
                        <b>Balance</b> : <span id='startBal' style='font-weight:bold;font-size:20px;'></span>
                        <!-- <table id="saletable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <td>Date</td>
                                    <td>Invoice No</td>
                                    <td>Vehicle No</td>
                                    <td>Job Description</td>
                                    <td>Amount</td>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th style="text-align: right;color: #00aaf1;"></th>
                                    <th id="totalpr" style="text-align: right;color: #00aaf1;"></th></tr>
                            </tfoot>
                        </table> -->
                        <table id="saletablex" class="table table-bordered">
                            <thead>
                                <tr>
                                    <td style="width:20px;"></td>
                                    <td style="width:150px;"></td>
                                    <td style="width:50px;"></td>
                                    <td style="width:100px;"></td>
                                    <td style="width:100px;"></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td>No of New Customers </td>
                                    <td></td>
                                    <td id="noofnewcus" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>No of Repeat Customers  </td>
                                    <td></td>
                                    <td id="noofrepcus" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>No Of New Jobs</td>
                                    <td></td>
                                    <td id="noofnewjob" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>No of Complete Jobs </td>
                                    <td></td>
                                    <td id="noofcomjob" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>No of Pending Jobs</td>
                                    <td></td>
                                    <td id="noofpendingjob" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>No of Over Due Jobs </td>
                                    <td></td>
                                    <td id="noofoverjob" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr><td colspan="5">&nbsp;</td></tr>
                                <tr>
                                    <td></td>
                                    <td>Start Cash Float  </td>
                                    <td></td>
                                    <td id="startfloat" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr><td colspan="5">Complete Jobs Payment Summary</td></tr>
                                <tr>
                                    <td></td>
                                    <td>Cash Jobs  </td>
                                    <td></td>
                                    <td id="cashjob" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr>
                                    <td></td>
                                    <td>Card Jobs  </td>
                                    <td></td>
                                    <td id="cardjob" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr>
                                    <td></td>
                                    <td>Advanced Jobs  </td>
                                    <td></td>
                                    <td id="advancejob" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr>
                                    <td></td>
                                    <td>Credit Jobs </td>
                                    <td></td>
                                    <td id="creditjob" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr><td colspan="5">&nbsp;</td></tr>
                                <tr><td colspan="5">Payment Summary</td></tr>
                                <tr>
                                    <td></td>
                                    <td>Supplier Payments  </td>
                                    <td></td>
                                    <td id="suppayment" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr><td colspan="5">&nbsp;</td></tr>
                                <tr>
                                    <td></td>
                                    <td>Employee Advance Payments  </td>
                                    <td></td>
                                    <td id="salaryadvance" class="text-right"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>Expenses  </td>
                                    <td></td>
                                    <td id="expOut" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr>
                                    <td></td>
                                    <td>Earning  </td>
                                    <td></td>
                                    <td id="expIn" class="text-right"></td>
                                    <td></td>
                                </tr>  
                                <tr><td colspan="5">
                                        <table id="saletable2" class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <td style="width:20px;"></td>
                                                    <td style="width:150px;"></td>
                                                    <td style="width:50px;"> In</td>
                                                    <td style="width:100px;"> Out</td>
                                                    <td style="width:100px;"></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>Day End Cash Float </td>
                                    <td></td>
                                    <td id="endFlaot" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                <tr><td colspan="5">&nbsp;</td></tr>
                                <tr>
                                    <td></td>
                                    <td>Operated Cashier</td>
                                    <td></td>
                                    <td id="cashier" class="text-right"></td>
                                    <td></td>
                                </tr> 
                                
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
        <!--print view modal-->
        <div id="salesbydateprint" class="modal fade bs-add-category-modal-lg" tabindex="-1" role="dialog" aria-hidden="false">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <!-- load data -->
                </div>
            </div>
        </div>
    </section>
</div>
<script>
    $('.input-daterange').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
    });
    
      $("#route").select2({
          placeholder: "Select a location"
      });
    var loc =[];
 $("#route").change(function(){
    loc.length=0;

    $("#route :selected").each(function(){
        loc.push($(this).val()); 
    });
    $("#route_ar").val(JSON.stringify(loc));
 });
 
    $('#filterform').submit(function (e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: "loaddailybalance",
            data: $(this).serialize(),
            success: function (data) {
                $('#saletable tbody,#saletable2 tbody').empty();
                drawTable(JSON.parse(data));

                $('#totalca').html(accounting.formatMoney(sumcolumn('cashamount')));
                $('#totalcra').html(accounting.formatMoney(sumcolumn('creditamount')));
                $('#totalcrda').html(accounting.formatMoney(sumcolumn('ccardamount')));
                $('#totalcha').html(accounting.formatMoney(sumcolumn('chequeamount')));
                $('#totalcoa').html(accounting.formatMoney(sumcolumn('costamount')));
                $('#totala').html(accounting.formatMoney(sumcolumn('totalamount')));
                $('#totaldia').html(accounting.formatMoney(sumcolumn('disamount')));
                $('#totalneta').html(accounting.formatMoney(sumcolumn('netamount')));
                $('#totalvata').html(accounting.formatMoney(sumcolumn('vatamount')));
                $('#totalnbta').html(accounting.formatMoney(sumcolumn('nbtamount')));
                $('#totalpr').html(accounting.formatMoney(sumcolumn('profit')));
                
            }
        })
    });
    var startBalance = 0;
    var totalCashIn=0;
    var totalCashOut=0;
    var totalExpIn=0;
    var totalExpOut=0;
    var totalSale = 0;
    var cashinhand=0;
    var totalCash=0;
    var posCash = 0;
    var prevjobSale=0;
    var prevposSale = 0;
    var totalNetSale=0;
    var totalsalaryAdvance=0;
    var totalSupPay=0;
    var posCard=0; var jobCard=0;
    var jobadvance=0;
    var cuspayment= 0;
    var jobadvancecard=0;
    var cuspaymentcard= 0;
    var endBalance=0;
    function drawTable(data) {
        startBalance = 0;
        endBalance=0;
        totalCashIn=0;
        totalCashOut=0;
        totalSale = 0;
        cashinhand=0;
        totalCash=0;
        posCash = 0;
        posCredit = 0;
        jobCredit = 0;
        cuspayment=0;
        prevjobSale=0;
        prevposSale = 0;
        totalNetSale=0;
        totalsalaryAdvance=0;
         totalSupPay=0;
        $("#noofnewcus").empty().html(accounting.formatMoney(data.newcus));
        $("#noofnewjob").empty().html(accounting.formatMoney(data.newjobs));
        $("#noofrepcus").empty().html(accounting.formatMoney(data.repcus));
        $("#noofcomjob").empty().html(accounting.formatMoney(data.completejobs));
        $("#noofpendingjob").empty().html(accounting.formatMoney(data.pendingjob));
        $("#noofoverjob").empty().html(accounting.formatMoney(data.overjob));
        startBalance=parseFloat(data.lastbal);
        $("#startfloat").html(accounting.formatMoney(startBalance));
        $("#startBal").html(accounting.formatMoney(startBalance));
        for (var i = 0; i < data.pro.length; i++) {
            drawRow(data.pro[i]);
        }

        for (var i = 0; i < data.product.length; i++) {
            drawProductRow(data.product[i]);
        }

        for (var i = 0; i < data.procash.length; i++) {
            posCash+=parseFloat(data.procash[i].CashAmount);
            posCredit+=parseFloat(data.cash[i].CreditAmount);
            posCard +=parseFloat(data.cash[i].CardAmount);
        }

        for (var i = 0; i < data.prevcash.length; i++) {
            prevjobSale+=parseFloat(data.prevcash[i].NetAmount);
        }

        for (var i = 0; i < data.prevprocash.length; i++) {
            prevposSale+=parseFloat(data.prevprocash[i].NetAmount);
        }

        for (var i = 0; i < data.inout.length; i++) {
            drawRowOut(data.inout[i]);
        }

        
        
           
           
       

        for (var i = 0; i < data.cash.length; i++) {
           totalCash+=parseFloat(data.cash[i].JobInvPayAmount);
           jobCredit+=parseFloat(data.cash[i].JobCreditAmount);
           jobCard +=parseFloat(data.cash[i].JobCardAmount);
        }

        for (var i = 0; i < data.salary.length; i++) {
           totalsalaryAdvance+=parseFloat(data.salary[i].CashAmount);
        }

        for (var i = 0; i < data.suppay.length; i++) {
           totalSupPay+=parseFloat(data.suppay[i].CashPay);
        }

        for (var i = 0; i < data.advance.length; i++) {
           jobadvance+=parseFloat(data.advance[i].CashPay);
           jobadvancecard+=parseFloat(data.advance[i].CardPay);
        }

        for (var i = 0; i < data.cuspay.length; i++) {
           cuspayment+=parseFloat(data.cuspay[i].CashPay);
           cuspaymentcard+=parseFloat(data.cuspay[i].CardPay);
        }

        for (var i = 0; i < data.expearn.length; i++) {

             if(data.expearn[i].IsExpenses==1){
                totalExpOut+=parseFloat(data.expearn[i].FlotAmount);
             }else if(data.expearn[i].IsExpenses==0){
                totalExpIn+=parseFloat(data.expearn[i].FlotAmount);
             }   
        }
        $("#expIn").html(accounting.formatMoney(totalExpIn));
        $("#expOut").html(accounting.formatMoney(totalExpOut));
        $("#salaryadvance").html(accounting.formatMoney(totalsalaryAdvance));
        $("#startBal").html(accounting.formatMoney(startBalance));
        $("#cashjob").html(accounting.formatMoney(posCash+totalCash+cuspayment));
        $("#cardjob").html(accounting.formatMoney(jobCard+posCard+cuspaymentcard+jobadvancecard));
        $("#creditjob").html(accounting.formatMoney(jobCredit+posCredit));
        $("#advancejob").html(accounting.formatMoney(jobadvance));
        $("#suppayment").html(totalSupPay);  
        endBalance=startBalance+totalCash+posCash-totalCashOut+totalCashIn-totalSupPay+jobadvance+cuspayment-totalExpOut+totalExpIn-totalsalaryAdvance;
        cashinhand =startBalance+totalCash+posCash-totalCashOut+totalCashIn;
        totalNetSale = totalSale + prevjobSale+prevposSale;
        $("#endFlaot").html(endBalance);  
        
       

    }

    function drawRow(rowData) {
        var row = $("<tr/>");
        $("#saletable").append(row);
        totalSale+=parseFloat(rowData.NetAmount);
        
        row.append($("<td>" + rowData.InvDate + "</td>"));
        row.append($("<td>" + rowData.JobInvNo + "</td>"));
        row.append($("<td>" + rowData.JRegNo + "</td>"));
        row.append($("<td colspan='10' align='left'>" + rowData.JobDescription + "</td>"));
        row.append($("<td class='profit' align='right'>" + accounting.formatMoney(rowData.NetAmount-rowData.AdvanceAmount) + "</td>"));
    }

    function drawProductRow(rowData) {
        var row = $("<tr/>");
        $("#saletable").append(row);
        totalSale+=parseFloat(rowData.NetAmount);
        
        row.append($("<td>" + rowData.InvDate + "</td>"));
        row.append($("<td>" + rowData.InvNo + "</td>"));
        row.append($("<td>" + rowData.InvProductCode + "</td>"));
        row.append($("<td colspan='10' align='left'>" + rowData.AppearName + "</td>"));
        row.append($("<td class='profit' align='right'>" + accounting.formatMoney(rowData.NetAmount) + "</td>"));
    }

    function drawRowOut(rowData) {
        var row = $("<tr/>");
        $("#saletable2").append(row);

        if(rowData.Mode=='Out'){
            
            totalCashOut+=parseFloat(rowData.CashAmount);
            row.append($("<td align='right'></td>"));
            row.append($("<td align='left'>" + rowData.TransactionName + " " + rowData.RepName + " " + rowData.Remark + "</td>"));
            row.append($("<td class='nbtamount2' align='right'>" + accounting.formatMoney(0) + "</td>"));
            row.append($("<td class='profit2' align='right'>" + accounting.formatMoney(rowData.CashAmount) + "</td>"));
            row.append($("<td align='right'></td>"));
        }else if(rowData.Mode=='In'){
            totalCashIn+=parseFloat(rowData.CashAmount);
            row.append($("<td align='right'></td>"));
            row.append($("<td align='left'>" + rowData.TransactionName + " " + rowData.RepName + " " + rowData.Remark+ "</td>"));
            row.append($("<td class='nbtamount2' align='right'>" + accounting.formatMoney(rowData.CashAmount) + "</td>"));
            row.append($("<td class='profit2' align='right'>" + accounting.formatMoney(0) + "</td>"));
            row.append($("<td align='right'></td>"));
        }
        
        
    }


    function sumcolumn(rclass) {
        var sum = 0;
        var elemnt = document.getElementsByClassName(rclass);
        $(elemnt).each(function () {
            var value = accounting.unformat($(this).text());

            if (!isNaN(value) && value.length != 0) {
                sum += parseFloat(value);
            }
        });
        return sum;
    }

    function loadprint() {
        $('.modal-content').load('<?php echo base_url() ?>admin/report/', function (result) {
            $('#salesbydateprint').modal({show: true});
        });
    }
    function printdiv() {
        var datebalance = $("#enddate").val();
        $("#printReport").print({
            prepend:"<h3 style='text-align:center'>Daily Cash Balance Report "+datebalance+"</h3><hr/>",
            title:'Daily Cash Balance Report '+datebalance
        });
    }
</script>